# Versioning

The documentation for this topic has been moved to the following articles in [Microsoft Learn](https://learn.microsoft.com/vcpkg):

* [vcpkg.json version fields](https://learn.microsoft.com/vcpkg/reference/vcpkg-json#version)
* [Versioning reference](https://learn.microsoft.com/vcpkg/users/versioning)
* [Versioning resolution algorithm](https://learn.microsoft.com/vcpkg/users/versioning.concepts)
