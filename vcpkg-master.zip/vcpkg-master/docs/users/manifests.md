# Manifests

The documentation for this topic has been moved to the following articles in [Microsoft Learn](https://learn.microsoft.com/vcpkg):

* [Manifest mode](https://learn.microsoft.com/vcpkg/users/manifests)
* [vcpkg.json syntax](https://learn.microsoft.com/vcpkg/reference/vcpkg-json)
